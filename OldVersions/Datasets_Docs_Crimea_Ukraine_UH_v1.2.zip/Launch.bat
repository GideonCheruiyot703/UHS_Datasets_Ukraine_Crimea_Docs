start luajit.exe x64.txt


